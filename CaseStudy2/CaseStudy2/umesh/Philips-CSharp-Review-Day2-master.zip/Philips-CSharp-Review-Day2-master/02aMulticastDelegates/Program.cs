﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MulticastDelegates
{
    public delegate void Logger(string logMessage);

    class Transaction
    {
        public void PrintMessage(string message)
        {
            Console.WriteLine($"Printing message to the console: {message}");
        }
    }



    class Program
    {
        public static void SendEmail(string message)
        {
            Console.WriteLine($"Emailing message: {message}");
        }


        static void Main(string[] args)
        {
            var t = new Transaction();

            var loggerDelegateInstance = new Logger(t.PrintMessage);

            //  Here SendEmail also conforms to the delegate signature. But SendEmail is a static method. This is okay.
            loggerDelegateInstance += SendEmail;    //  This is like adding to an internal list of methods. It's called as multicasting the delegate.

            //  Internally type of delegate is a special class derived from .NET abstract class called MulticastDelegate. 
            //  In the beta versions of .NET, the concept of multicast delegates didn't exist. MulticastDelegate derives from Delegate.
            //  From docs: MulticastDelegate is a special class. Compilers and other tools can derive from this class, but you cannot derive from it explicitly. The same is true of the Delegate class.

            //  Now this delegate instance loggerDelegateInstance has two methods in its 'invocation list'. When we invoke or simply call, the underlying methods are called in the order we added.

            loggerDelegateInstance.Invoke("Invoking the delegate");     //  same result can be achieved through new way: loggerDelegateInstance("Invoking the delegate");    

            //  We can remove an underlying method
            loggerDelegateInstance -= SendEmail;

            //  Only one method in the invocation list now
            loggerDelegateInstance.Invoke("Invoking the delegate");

        }
    }
}
