﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericDelegates
{
    public delegate T Calculate<T>(T input);

    class Program
    {
        public static int Do(int val)
        {
            return ++val;
            
        }

        static void Main(string[] args)
        {
            var gd = new Calculate<int>(Do);

            var gd1 = new Calculate<string>(delegate (string str)
            {
                return $"From an anonymous method {str}";
            });

            var gd2 = new Calculate<string>(str => { return $"From a lambda expression {str}"; });

            Console.WriteLine(gd.Invoke(100));
            Console.WriteLine(gd2.Invoke("String invocation"));
        }
    }
}
