﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS13Enums
{
    //  Enums are internally integers but externally labels. Kind of named constants, if you will.
    //  Elements inside an enum should follow rules of identifiers such as variable name
    public enum HealthStatus    //  normal enum, first element is set to value 0
    {
        Healthy,
        DiseaseCondition,
        Ill,
        CriticallyIll,
        Death
    }



    public enum Answer  //  value assignment can be in any order so long as values and elements are unique
    {
        I_am_really_confused = 3,
        I_am_confident_about_my_answer = 0,
        I_do_not_wish_to_anser = 2,
        I_am_coerced_to_anwer = 1
    }


    public enum AbruptEnum
    {
        Option0,
        Option1 = 100,
        Option2     //  This is 101
    }

    class Program
    {
        static void Main(string[] args)
        {
            //  Since enum is a type, we can use it as such
            var myAnswer = Answer.I_am_confident_about_my_answer;

            Answer a = new Answer();    //  This is also possible, but rarely ever done.
            a = Answer.I_am_confident_about_my_answer;

            //  getting the underlying integer value by explicit cast
            var value = (int)myAnswer;

            //  converting int value to enum
            var a1 = (Answer)3;

            //  converting string value to enum
            //  this process is exception-prone, do not forget to use this inside try/catch block
            var eAnswer = (Answer)Enum.Parse(typeof(Answer), "I_am_really_confused");

            //  converting string to enum, verbose but safer way (without using try/catch)
            //  TryParse produces two results: actual enum as out; and result of operation as a boolean return value
            Answer a2;
            var result = Enum.TryParse<Answer>("I_am_coerced_to_anwer", out a2);

            //  At this time, we are not yet sure whether a2 is a valid value (it is null otherwise)
            if (result)
            {
                Console.WriteLine(a2);
            }
        }
    }
}
