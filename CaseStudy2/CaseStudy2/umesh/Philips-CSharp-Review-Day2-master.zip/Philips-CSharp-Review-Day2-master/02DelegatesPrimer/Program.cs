﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesPrimer
{
    //  Delegate is a type just like class, struct, interface, enum
    //  A delegate declaration is more like a method signature in an interface
    //  This delegate type can be assigned with a method that takes a string parameter and returns nothing
    //  We cannot provide the method body here. This is just a declaration of the type.
    public delegate void Logger(string logMessage);

    class Transaction
    {
        public void PrintMessage(string message)
        {
            Console.WriteLine($"Printing message to the console: {message}");
        }
    }



    class Program
    {
        static void Main(string[] args)
        {
            var t = new Transaction();

            //  Look at this strange instantiation of the delegate object
            //  We have to provide an actual method (instance or static) whose signature matches the delegate
            //  Here we have an instance method PrintMethod from t object, which matches the delegate
            //  var loggerDelegateInstance = new Logger();  // Error. Instantiation of delegate object requires a matching method to be provided in the constructor.
            var loggerDelegateInstance = new Logger(t.PrintMessage);

            //  Now loggerDelegateInstance starts to refer to PrintMessage
            //  Therefore, we do

            loggerDelegateInstance("From delegate object"); //  This is like calling a method. We say we are 'invoking' a delegate

            loggerDelegateInstance.Invoke("Through delegate invocation");   //  This was the old method. Internally both are same. Compiler emits the same MSIL.

        }
    }
}
