﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Variance
{
    interface ICoffeeVendorContraVariance<in T>
    {
        
    }

    class CoffeeVendingMachineContraVariance<T> : ICoffeeVendorContraVariance<T>
    {
        
    }

    interface ICoffeeVendorCoVariance<out T>
    {
        
    }

    class CoffeeVendingMachineCoVariance<T> : ICoffeeVendorCoVariance<T>
    {
        
    }

    class ParentCoffee
    {

    }

    class ChildCoffee : ParentCoffee
    {

    }

    class Program
    {
        static void Main(string[] args)
        {
            //  Contravariance
            ICoffeeVendorContraVariance<ChildCoffee> contravar = new CoffeeVendingMachineContraVariance<ParentCoffee>();

            //  Covariance
            ICoffeeVendorCoVariance<ParentCoffee> covar = new CoffeeVendingMachineCoVariance<ChildCoffee>();

            IEnumerable<int> list = new List<int> { 1, 2, 3, 4, 5, 6, 7 };
            IEnumerable<char> str = "Hello world!";
        }
    }
}
