﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateUsage02
{
    delegate void TransmitMessage(string message);

    class Store
    {
        //  To prevent outsiders from abusing the raw delegate, we just add event keyword to the delegate instance we use internally. Rest is same.
        public event TransmitMessage TransmitMessageDelegateInstance;

        public void ProcessOrder(int orderId)
        {
            //... Order processing algorithm

            //  This class knows nothing about the exact methods underlie loggerDelegateInstance
            //  Perhaps the Store class may as well be written by a third-party
            //  All it cares is to mimic an event
            //  Our intention is to plugin our methods to this delegate
            TransmitMessageDelegateInstance($"Store invokes the delegate for order id: {orderId}");
        }
    }
    class Program
    {
        public static void SendSMS(string message)
        {
            Console.WriteLine($"SMS: {message}");
        }

        public static void SendEmail(string message)
        {
            Console.WriteLine($"Email: {message}");
        }

        public static void SendCloudMessage(string message)
        {
            Console.WriteLine($"Cloud Message: {message}");
        }


        static void Main(string[] args)
        {
            var s = new Store();

            //  Since the TransmitMessageDelegateInstance is now decorated with event, we cannot intialize it with a new delegate instance.
            //  All we can do is add (+=) or remove (-=)

            //  These methods on the RHS are the subscribers or listeners for the event
            s.TransmitMessageDelegateInstance += SendSMS;
            s.TransmitMessageDelegateInstance += SendEmail;
            s.TransmitMessageDelegateInstance += SendSMS;

            s.ProcessOrder(100);

            //  s.TransmitMessageDelegateInstance = null;   //  This is now not possible
        }
    }
}
