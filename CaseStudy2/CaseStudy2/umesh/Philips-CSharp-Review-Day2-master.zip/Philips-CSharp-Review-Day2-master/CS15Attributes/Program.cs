﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CS15Attributes
{
    [System.AttributeUsage(AttributeTargets.All, Inherited = false, AllowMultiple = true)]
    sealed class DebugAttribute : Attribute
    {
        // See the attribute guidelines at 
        //  http://go.microsoft.com/fwlink/?LinkId=85236
        readonly string positionalString;

        // This is a positional argument
        public DebugAttribute(string positionalString)
        {
            this.positionalString = positionalString;

        }

        public string PositionalString
        {
            get { return positionalString; }
        }

        // This is a named argument
        public int NamedInt { get; set; }
    }

    [Debug("Args")]
    class CarWithDebug
    {
        
        public void Drive()
        {
            //...
        }

        public void Foo(string message)
        {
            //...
        }
    }

    class CarWithoutDebug
    {

    }

    class Program
    {
        static void Main(string[] args)
        {
            var types = Assembly.GetExecutingAssembly().GetTypes().Where(t=>t.GetCustomAttributes<DebugAttribute>().Count() > 0);

            foreach (var type in types)
            {
                Console.WriteLine($"Type: {type.Name}");

                var methods = type.GetMethods();

                foreach (var method in methods)
                {
                    Console.WriteLine($"Method: {method.Name}, Params: {method.GetParameters()}");
                }
                
            }
        }
    }
}
