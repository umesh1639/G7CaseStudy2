﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Reflection
{
    class Sample
    {
        private bool IsActive = false;
        public string Label = "Some Label";
        public int Number { get; set; }
        public string Name { get; set; } = "Default Value";

        public int Foo(string message)
        {
            Console.WriteLine($"Foo printing the message: {message}");
            return 100;
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            var sample = new Sample();

            var assembly = Assembly.GetExecutingAssembly();

            var name = assembly.FullName;

            Console.WriteLine(name);

            var types = assembly.GetTypes();

            

            foreach (var type in types)
            {
                Console.WriteLine(type.FullName);
                var props = type.GetProperties();
                var fields = type.GetFields();
                var methods = type.GetMethods();

                var foo = type.GetMethod("Foo");

                Console.WriteLine("Properties");
                foreach (var prop in props)
                {
                    Console.WriteLine($"\t{prop.Name}");
                }

                Console.WriteLine("Fields");
                foreach (var field in fields)
                {
                    Console.WriteLine($"\t{field.Name}");
                }

                Console.WriteLine("Methods");
                foreach (var method in methods)
                {
                    Console.WriteLine($"\t{method.Name}");
                }

                
            }

            Type sampleType = assembly.GetType("Reflection.Sample");
            var nameSampleProp = sampleType.GetProperty("Name");

            object sampleInstance = Activator.CreateInstance(sampleType);

            string valDefault = (string)nameSampleProp.GetValue(sampleInstance, null);
            Console.WriteLine(valDefault);

            nameSampleProp.SetValue(sampleInstance, "Reflection value", null);
            string valReflection = (string)nameSampleProp.GetValue(sampleInstance, null);
            Console.WriteLine(valReflection);

            var fooMethod = sampleType.GetMethod("Foo");

            var paramsArray = new object[] { "This is my message" };
            var valReturn = fooMethod.Invoke(sampleInstance, paramsArray);

            Console.WriteLine(valReturn);

            var privateFields = sampleType.GetFields(BindingFlags.NonPublic | BindingFlags.Instance);

            foreach (var field in privateFields)
            {
                Console.WriteLine($"Here is the private field: {field.Name}");
            }
        }
    }
}
