﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexersAndIEnumerable
{
    class DummyCollection<T>
    {
        private T[] internalArray = new T[25];

        //  This is the indexer, which lets the users subscript or use indexes to access the elements in a custom collection
        public T this[int i]
        {
            get { return internalArray[i]; }
            set { internalArray[i] = value; }
        }
    }


    //  We make the custom collection class iterable by implementing IEnumerable<T> interface
    //  This is the case of a generic class implementing a generic interface
    class DummyEnumerableCollection<T> : IEnumerable<T>
    {
        public List<T> InternalList { get; set; }

        //  Indexer
        public T this[int i]
        {
            get { return InternalList[i]; }
            set { InternalList[i] = value; }
        }

        //  foreach loop construct calls this method for every iteration
        //  This is a genetic method
        public IEnumerator<T> GetEnumerator()
        {
            //  We are just returning the GetEnumerator of the List collection class, which implements IEnumerable<T>
            //  Every array in .NET by default implements the IEnumerable, but that is non-generic version.
            //  Therefore to work with generic types, we are using list instead of array here in this example.
            return InternalList.GetEnumerator();
        }

        //  This is non-generic version. Legacy.
        IEnumerator IEnumerable.GetEnumerator()
        {
            return InternalList.GetEnumerator();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            var dc = new DummyCollection<string>();

            dc[0] = "Good day!";

            Console.WriteLine(dc[0]);

            var dec = new DummyEnumerableCollection<int> { InternalList = new List<int> { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 } };

            foreach (var el in dec)
            {
                Console.WriteLine(el);
            }
        }
    }
}
