﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateUsage
{
    delegate void TransmitMessage(string message);

    class Store
    {
        public event TransmitMessage TransmitMessageDelegateInstance;

        public void ProcessOrder(int orderId)
        {
            //... Order processing algorithm

            //  This class knows nothing about the exact methods underlie loggerDelegateInstance
            //  Perhaps the Store class may as well be written by a third-party
            //  All it cares is to mimic an event
            //  Our intention is to plugin our methods to this delegate

            //if (TransmitMessageDelegateInstance != null)
            //{
            //    TransmitMessageDelegateInstance($"Store invokes the delegate for order id: {orderId}");
            //}

            TransmitMessageDelegateInstance?.Invoke($"Store invokes the delegate for order id: {orderId}");

        }
    }
    class Program
    {
        public static void SendSMS(string message)
        {
            Console.WriteLine($"SMS: {message}");
        }

        public static void SendEmail(string message)
        {
            Console.WriteLine($"Email: {message}");
        }

        public static void SendCloudMessage(string message)
        {
            Console.WriteLine($"Cloud Message: {message}");
        }


        static void Main(string[] args)
        {
            var s = new Store();

            // s.TransmitMessageDelegateInstance = new TransmitMessage(SendSMS);
            //s.TransmitMessageDelegateInstance += SendCloudMessage;
            //s.TransmitMessageDelegateInstance += SendEmail;
            //s.TransmitMessageDelegateInstance += SendSMS;
            //s.TransmitMessageDelegateInstance += SendSMS;

            //s.ProcessOrder(100);

            // s.TransmitMessageDelegateInstance = null;   //  This is the danger with using raw delegates for mimicing events
            s.ProcessOrder(120);    //  This throws NullReferenceException, because store is trying to invoke a delegate which is null
        }
    }
}
