﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Events
{
    class TransmitMessageEventArgs : EventArgs
    {
        // These are properties. They look more like fields, but they are not.
        public string Category { get; set; }
        public DateTime TimeStamp { get; set; }
        public string Message { get; set; }
    }

    class Store
    {
        //  Instead of our own delegate type, we now use a general-purpose EventHandler<T> delegate, which is generic.
        //  This means, we can pass on information related to the event in our type.
        //  In .NET, this kind of information container class is derived from EventArgs class
        //  Therefore, we have our own container class: TransmitMessageEventArgs

        public event EventHandler<TransmitMessageEventArgs> EventHandlerDelegateInstance;

        public void ProcessOrder(int orderId)
        {
            //... Order processing algorithm

            //   Let's create the information we want to give out about this event
            //   

            var tmea = new TransmitMessageEventArgs //  This is the object intializer syntax
            {
                Category = "Transaction",
                TimeStamp = DateTime.Now,
                Message = $"Store invokes the delegate for order id: {orderId}"
            };

            //  Finally 'raise' the event
            EventHandlerDelegateInstance(this, tmea);
        }
    }
    class Program
    {
        private static void SendCloudMessage(object sender, TransmitMessageEventArgs e)
        {
            Console.WriteLine($"Cloud Message: Category: {e.Category}, Message: {e.Message} at {e.TimeStamp.ToString()}");
        }

        private static void SendEmail(object sender, TransmitMessageEventArgs e)
        {
            Console.WriteLine($"Email: Category: {e.Category}, Message: {e.Message} at {e.TimeStamp.ToString()}");
        }

        private static void SendSMS(object sender, TransmitMessageEventArgs e)
        {
            Console.WriteLine($"SMS: Category: {e.Category}, Message: {e.Message} at {e.TimeStamp.ToString()}");
        }

        static void Main(string[] args)
        {
            var s = new Store();


            s.EventHandlerDelegateInstance += SendSMS;
            s.EventHandlerDelegateInstance += SendEmail;
            s.EventHandlerDelegateInstance += SendCloudMessage;

            s.EventHandlerDelegateInstance += (sender, e) => Console.WriteLine($"SMS: Category: {e.Category}");

            s.ProcessOrder(100);
        }


    }
}
