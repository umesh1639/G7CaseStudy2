﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQPrimer
{
    class Novel
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public int Pages { get; set; }
        public string Language { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            IEnumerable<Novel> list = new List<Novel>
            {
                new Novel{Author = "Leo Tolstoy", Language="Russian", Pages=1500, Title="War and Peace"},
                new Novel{Author = "Leo Tolstoy", Language="Russian", Pages=900, Title="Anna Karenina"},
                new Novel{Author = "Fyodor Dostoyevsky", Language="Russian", Pages=800, Title="Crime and Punishment"},
                new Novel{Author = "Fyodor Dostoyevsky", Language="Russian", Pages=1200, Title="Karamazov Brothers"},
                new Novel{Author = "Victor Hugo", Language="French", Pages=1800, Title="Les Miserables"},
                new Novel{Author = "Vladimir Nobakov", Language="English", Pages=500, Title="Lolita"},
                new Novel{Author = "Gustave Flaubert", Language="French", Pages=800, Title="Madame Bovary"},
            };

           

            //  this is LINQ. Where takes a generic delegate instance of type Func from .NET
            //  We use lambda expressions here.
            //  Filter multiple
            //var russianNovels = list.Where(n => n.Language == "Russian");   //  n is implicitly the Novel, we
            

            //var moreThan1000Pages = list.Where(n => n.Pages > 1000);

            ////  Projection
            //var onlyTitles = list.Select(n => new { n.Title });

            //foreach (var item in onlyTitles)
            //{
            //    Console.WriteLine(item.Title);
            //}

            //  Sort
            var sortedList = list.OrderBy(n => n.Title);
            foreach (var item in sortedList)
            {
                Console.WriteLine(item.Title);
            }

            //  Filter single
            var firstRussianNovel = list.FirstOrDefault(n => n.Language == "Russian");
            Console.WriteLine(firstRussianNovel.Title);

            //  Filter single with combined search criteria
            var combinedResult = list.FirstOrDefault(n => n.Language == "Russian" && n.Pages < 1000);
            Console.WriteLine(combinedResult.Title);
        }
    }
}
