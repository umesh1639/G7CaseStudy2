﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethodsAndAnonymousTypes
{
    //  Extension methods let us add desired functionality to existing types without having to create their derived types.
    //  In this example, we are going to add our own functionality to the built-in type string
    //  The intention is to get this method as if it were a native method on the string type

    //  Extension method has to be declared in a non-generic and static class
    //  Conventionally this class is suffixed with Extensions
    static class StringExtensions
    {
        //  This is the desired extension method
        //  The first parameter should be an object of the type we want the extension method to be part of.
        //  In this case, we want this method to be associated with string type, therefore the first parameter is string
        //  This first parameter has to be decorated with this
        //  The extension method can have as many parameters after this mandatory first one. In this case, we declare one extra parameter
        public static int GetLetterCount(this string str, char letter)
        {
            var count = 0;

            foreach (var ch in str)
            {
                if (ch == letter)
                {
                    count++;
                }
            }

            return count;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            var str = "War and peace is a great novel by Leo Tolstoy";

            //  the first mandatory parameter is automatically inferred when we call extension method with the desired type (string in this case)
            //  therefore we see only the extra parameter
            var countOfAs = str.GetLetterCount('a');

            Console.WriteLine(countOfAs);


            //  This is an anonymous type usage. Here, person is an object of an anonymous type.
            //  This means, we cannot create another person using the same blue print
            var person = new { Name = "Rajesh", Age = 25 };


            //  Anonymous types are simple wrappers around readonly properties (no methods, fields, events are allowed)
            //  These are reference types that derive implicitly from object like other reference types
            //  Compiler creates an actual class behind the scene, though we cannot access the underlying class
            //  Compiler also optimizes the underlying class creation by employing other methods

            Console.WriteLine($"From anonymous type: {person.Name}, {person.Age}");
        }
    }
}
