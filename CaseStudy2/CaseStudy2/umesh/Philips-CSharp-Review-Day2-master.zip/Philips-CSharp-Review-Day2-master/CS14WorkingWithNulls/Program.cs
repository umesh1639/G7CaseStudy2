﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS14WorkingWithNulls
{
    class Owner
    {
        public string Name { get; set; }
    }
    class Car
    {
        public DateTime ServicedAt { get; set; }
        public Owner Owner { get; set; }
        public string Model { get; set; }
        public int YOM;
    }
    class Program
    {
        static int classInt;
        static void Main(string[] args)
        {
            var car = new Car();

            //  At this time, we have not initialized the Owner property of the Car.
            //  Owner is a class (a reference type). Therefore this property, if not initialized, will be 'null'
            //  If we try to access this property like: car.Owner.Name = "X"; we get the infamous NullReferenceException.
            //  This means, we are trying to use the reference which doesn't point to any object in memory.
            //  If we get references from outside code, we must therefore ensure they are not null
            //  Dealing with nulls is painful and at times frustrating.

            var isOwnerNull = car.Owner == null;
            var isModelNull = car.Model == null;


            //  null conditional operator
            Console.WriteLine(car.Owner?.Name); //  Access Name only if car.Owner is not null

            //  null coalescing operator
            string ownerName = car?.Owner?.Name ?? "Default";   // assign car.Owner.Name if Name is not null, else set "Default"

            //  Remember, value types such as int, DateTime, double are never null, even if uninitialized. If uninitialized, they take default values.
            Console.WriteLine(car.YOM); //  YOM is uninitialized, hence takes default value of zero. ServicedAt also takes the default value. Check what is that?!

            //  comparison is possible only for uninitialized class-level variables
            var isClassIntZero = classInt == 0;

            //  At the same time, you cannot compare the unitialized block/function scoped value/reference type
            int localInt;
            //  var isLocalIntZero = localInt == 0; //  You cannot use uninitialized local variable

            Car anotherCar;
            //  var isLocalRefTypeNull = anotherCar == null;    //  You cannot use uninitialized local variable (even though it is a reference type)

            //  Nullable value types are used in special cases:
            int? nullableInt = null;    //  int? is an alias for Nullable<int>
            DateTime? dateOfBirth = null;//  DateTime? is an alias for Nullable<DateTime>

            Nullable<int> verboseNullableInt = null;    //  verbose way
            Nullable<DateTime> dob = null;  //  verbose way

            //  Nullable types behave like their normal couterparts
            nullableInt = 100;

            var isThis100 = nullableInt == 100; //  true

            //  But assignment to its normal counterpart is not possible
            //  int normalInt = nullableInt;    //  this is not possible
            //  If you are so sure that it is not null at the time of assignment, use .Value property
            //  But this is exception-prone, since int val = null is an exception
            int normalInt = nullableInt.Value;

            //  combining ideas discussed so far:
            int x = nullableInt ?? 0;
        }
    }
}
