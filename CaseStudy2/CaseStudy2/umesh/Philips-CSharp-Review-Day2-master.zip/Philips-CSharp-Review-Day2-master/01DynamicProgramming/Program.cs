﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DynamicProgramming
{
    class Sample
    {
        public int Number { get; set; }

        public void Foo(string message)
        {
            Console.WriteLine($"Sample class: Foo {message}");
        }

        public int Bar()
        {
            return 100;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            dynamic dv1 = new Sample { Number = 7 };    //  type of dv1 is dynamic. It is not casting. There is no boxing. 

            Console.WriteLine(dv1.Number);  //  This is not boxing, but run-time type inference. This behaviour is like Python or Ruby.

            dv1.Foo("Calling from dynamic");    //  Thre is no compile-time checking. So, this call may as well throw a runtime exception.

            var val = dv1.Ba();    //  Since dv1 has dynamic type at compile-time, calling a method (that otherwise returns a static type such as int) will also produce dynamic variable in compile-time.
            Console.WriteLine($"val is of type{val.GetType()}");    //  But at run-time its type is correctly inferred as Int32. Just like dynamic languages (Python, Ruby, JavaScript)

            //  There is no complaint at compile-time (assigning the void return to a variable).  
            //  But when this is executed, we get RuntimeBinderException
            //var val2 = dv1.Foo("Good day!");     

            //dynamic dv2 = "Good";

            //var s = new Sample();

            ////s.Number = dv2; //  This is both a gift and a curse.

            //dynamic dv3 = 123;
            //s.Foo(dv3); //  Gift or a curse?

            dynamic dv4 = DateTime.Now;
            DateTime now = dv4;

            Console.WriteLine(dv4);
            Console.WriteLine(now); //  Both produce the same output
        }
    }
}
