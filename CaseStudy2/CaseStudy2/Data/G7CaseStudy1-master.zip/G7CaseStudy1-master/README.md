# G7CaseStudy1

Problem Statement - Integrate data from different static-analysis tooling
We have used Two tools  
  1) CSharpMetrics
  2) NDepend
  
Procedure :

  Input--Solution Directory(e.g: C:\Users\320069097\source\repos\G7CaseStudy1\StaticAnalyzer)
  
  Intermediate Output-- XML file-->Then this XML will be Parsed 
  
  Output--- Full List of Metrics for respective tools
